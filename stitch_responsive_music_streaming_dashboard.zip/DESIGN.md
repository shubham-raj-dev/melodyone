---
name: Sonic Ethereal
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#4a4455'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#7b7487'
  outline-variant: '#ccc3d8'
  surface-tint: '#F1F5F9'
  primary: '#630ed4'
  on-primary: '#ffffff'
  primary-container: '#7c3aed'
  on-primary-container: '#ede0ff'
  inverse-primary: '#d2bbff'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#7d3d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#a15100'
  on-tertiary-container: '#ffe0cd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#eaddff'
  primary-fixed-dim: '#d2bbff'
  on-primary-fixed: '#25005a'
  on-primary-fixed-variant: '#5a00c6'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#aec6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb784'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  glass-stroke: rgba(255, 255, 255, 0.6)
  accent-purple-vibrant: '#9D50FF'
  accent-blue-electric: '#2E90FF'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter-md: 16px
  margin-lg: 24px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style
The design system transitions the "Sonic Ethereal" identity into a premium, high-clarity light mode. The personality is sophisticated, airy, and hyper-modern, targeting an audience that values precision and a high-end digital feel. 

The visual style is a refined **Glassmorphism** set against a "Super White" canvas. It moves away from deep glows to focus on light refraction, using subtle blue-tinted shadows and translucent white layers to create depth. The aesthetic feels like a clean, sunlit studio—professional yet infused with the vibrant energy of the music industry through its electric purple and blue accents.

## Colors
The palette is anchored by a luminous, high-contrast light theme. Surfaces are not flat white but are subtly infused with cool slate and blue tones to prevent eye strain and add a premium "crystalline" quality.

- **Primary:** A vibrant Purple (#7C3AED) used for critical calls to action and active states. It is calibrated for WCAG 2.1 AA compliance against light backgrounds.
- **Secondary:** An Electric Blue (#0566D9) used for progress indicators, secondary interactive elements, and data visualization.
- **Surface & Background:** The main background is a pristine White (#FFFFFF), while containers use a very light Slate (#F8FAFC) to create subtle separation.
- **Gradients:** High-impact elements should utilize a linear 45-degree gradient transitioning from the vibrant purple to the electric blue.

## Typography
**Hanken Grotesk** is the sole typeface, ensuring a unified, tech-forward appearance. In this light-themed iteration, the typography relies on high-contrast ink levels (Deep Slate #1E293B for headings) to ensure maximum readability.

Headlines use tight tracking and bold weights to command attention, mirroring the confidence of the brand. Body text is set with generous line-heights to maintain an "airy" feel, ensuring that content remains legible even when placed over semi-transparent glass layers.

## Layout & Spacing
The layout employs a **Fluid Grid** that prioritizes white space to support the premium brand narrative. 

- **Grid System:** A standard 12-column grid for desktop (max-width 1440px) and a 4-column grid for mobile.
- **Rhythm:** An 8px base unit drives all spatial decisions. Large-scale components (cards, sections) should favor the `stack-lg` (48px) spacing to prevent the interface from feeling cluttered.
- **Safe Areas:** Glassmorphic containers require internal padding of at least 24px to ensure text does not clash with the rounded, frosted edges of the container.

## Elevation & Depth
Elevation is conveyed through a combination of **Tonal Layers** and **Glassmorphism**. 

1. **The Base:** The background is #FFFFFF. 
2. **Elevated Containers:** Use a "Frosted Glass" effect: `backdrop-filter: blur(30px)` with a semi-transparent white fill `rgba(255, 255, 255, 0.7)`.
3. **Shadows:** Unlike the dark mode, this system uses "Ambient Shadows"—extremely soft, large-radius blurs (40px-60px) with very low opacity (5-8%) tinted with a hint of blue (#0F172A) to simulate natural depth.
4. **Defined Edges:** A subtle 1px border using `rgba(0, 0, 0, 0.05)` or a light-facing "inner glow" provides structural integrity to glass panels.

## Shapes
The shape language is **Rounded** and organic. All major structural components use a 1rem (16px) radius to soften the technical edge of the Hanken Grotesk typeface.

- **Primary Containers:** 1.5rem (24px) for cards and main modules.
- **Interactive Elements:** 0.75rem (12px) for buttons and input fields to maintain a compact, tactile feel.
- **Pill Shapes:** Used exclusively for status indicators, chips, and tags to distinguish them from actionable buttons.

## Components

### Buttons
- **Primary:** Solid gradient fill (Purple to Blue) with white text. On hover, the button scales slightly (1.02x) and the shadow intensifies.
- **Secondary/Outline:** A 1.5px stroke using the primary purple color with a transparent background.

### Input Fields
- White backgrounds with a 1px border in `slate-200`. On focus, the border transitions to the primary purple, and a subtle 4px "outer glow" of the same color is applied.

### Cards
- Utilizes the glassmorphic style described in Elevation. Headlines should be `slate-900` for maximum contrast, while metadata uses `slate-500`.

### Chips & Tags
- Soft, pill-shaped elements with a very light background tint (e.g., 10% opacity of the primary color) and matching text color for a clean, tonal look.

### Progress & Seek Bars
- The track uses a light `slate-100` fill. The active progress uses the brand gradient. The handle/thumb should be a crisp white circle with a subtle drop shadow to appear "above" the track.